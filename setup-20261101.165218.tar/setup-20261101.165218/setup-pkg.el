;;; Generated package description from setup.el  -*- no-byte-compile: t -*-
(define-package "setup" "20261101.165218" "Helpful Configuration Macro" '((emacs "26.1")) :authors '(("Philip Kaludercic" . "philipk@posteo.net")) :maintainer '("Philip Kaludercic" . "philipk@posteo.net") :keywords '("lisp" "local") :url "https://codeberg.org/pkal/setup.el")
