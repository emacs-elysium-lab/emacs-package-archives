(define-package "haskell-ng-mode" "20260830.174758"
  "A mode for Haskell"
  '((emacs "29") (dash "0") (f "0") (project "0")) :keywords
  '("cabal" "haskell" "languages" "tree-sitter") :url
  "https://gitlab.com/magus/haskell-ng-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
