(define-package "sly-el-indent" "20200816.230527"
  "Use sly-cl-indent to indent Elisp" '((emacs "24.3")) :authors
  '(("Zhu Zihao" . "all_but_last@163.com")) :maintainer
  '("Zhu Zihao" . "all_but_last@163.com") :keywords '("lisp") :url
  "https://github.com/cireu/sly-el-indent")
;; Local Variables:
;; no-byte-compile: t
;; End:
