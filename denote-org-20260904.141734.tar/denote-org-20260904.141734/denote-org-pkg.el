(define-package "denote-org" "20260904.141734"
  "Denote extensions for Org mode" '((emacs "28.1") (denote "4.0.0"))
  :authors '(("Protesilaos" . "info@protesilaos.com")) :maintainer
  '("Protesilaos" . "info@protesilaos.com") :url
  "https://github.com/protesilaos/denote-org")
;; Local Variables:
;; no-byte-compile: t
;; End:
