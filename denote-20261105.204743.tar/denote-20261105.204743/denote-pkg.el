(define-package "denote" "20261105.204743"
  "Simple notes with an efficient file-naming scheme"
  '((emacs "28.1")) :authors
  '(("Protesilaos" . "info@protesilaos.com")) :maintainer
  '("Protesilaos" . "info@protesilaos.com") :url
  "https://github.com/protesilaos/denote")
;; Local Variables:
;; no-byte-compile: t
;; End:
