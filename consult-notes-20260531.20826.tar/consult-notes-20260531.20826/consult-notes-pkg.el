(define-package "consult-notes" "20260531.20826"
  "Manage notes with consult"
  '((emacs "28.1") (consult "1.0") (s "1.12.0") (dash "2.19")))
;; Local Variables:
;; no-byte-compile: t
;; End:
