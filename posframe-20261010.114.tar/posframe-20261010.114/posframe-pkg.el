;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "posframe" "20261010.114"
  "Pop a posframe (just a frame) at point."
  '((emacs "26.1"))
  :url "https://github.com/tumashu/posframe"
  :commit "1d833af5c43313e401be2e5c456bf03d4ce9519c"
  :revdesc "1d833af5c433"
  :keywords '("convenience" "tooltip")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
