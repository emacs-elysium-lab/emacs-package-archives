(define-package "denote-org" "20251201.130049"
  "Denote extensions for Org mode" '((emacs "28.1") (denote "4.0.0"))
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url
  "https://github.com/protesilaos/denote-org")
;; Local Variables:
;; no-byte-compile: t
;; End:
