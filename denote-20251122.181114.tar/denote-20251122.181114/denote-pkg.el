(define-package "denote" "20251122.181114"
  "Simple notes with an efficient file-naming scheme"
  '((emacs "28.1")) :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com") :url
  "https://github.com/protesilaos/denote")
;; Local Variables:
;; no-byte-compile: t
;; End:
