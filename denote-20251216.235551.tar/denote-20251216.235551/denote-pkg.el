(define-package "denote" "20251216.235551"
  "Simple notes with an efficient file-naming scheme"
  '((emacs "28.1")) :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com") :url
  "https://github.com/protesilaos/denote")
;; Local Variables:
;; no-byte-compile: t
;; End:
