;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20261107.2037"
  "LSP mode."
  '((emacs         "29.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "7f3a6575a1779fd69078825178ba0ed330944ff2"
  :revdesc "7f3a6575a177"
  :keywords '("languages"))
