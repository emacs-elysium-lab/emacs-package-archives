;;; Generated package description from chairs.el  -*- no-byte-compile: t -*-
(define-package "chairs" "20251024.124603" "CHAnge or add surrounding pAIRS" '((emacs "28.1") (expand-region "0.7")) :keywords '("extensions" "convenience") :url "https://github.com/emacs-elysium-lab/chairs.el")
