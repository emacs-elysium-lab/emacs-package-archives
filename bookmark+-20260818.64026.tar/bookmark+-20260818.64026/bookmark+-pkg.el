(define-package "bookmark+" "20260818.64026"
  "Bookmark+: extensions to standard library `bookmark.el'." 'nil
  :maintainer
  '("Drew Adams (concat \"drew\" \"0000\" \"0001\" \"ail\" \".com\""
    . "\"@gm\" ")
  :keywords
  '("bookmarks" "bookmark+" "projects" "placeholders" "annotations"
    "search" "info" "url" "eww" "w3m" "gnus")
  :url "https://www.emacswiki.org/emacs/download/bookmark%2b.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
