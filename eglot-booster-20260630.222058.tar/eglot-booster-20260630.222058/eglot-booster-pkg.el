;;; Generated package description from eglot-booster.el  -*- no-byte-compile: t -*-
(define-package "eglot-booster" "20260630.222058" "Boost eglot using lsp-booster" '((emacs "29.1") (jsonrpc "1.0") (eglot "1.0") (seq "2.24")) :keywords '("convenience" "programming") :url "https://github.com/jdtsmith/eglot-booster")
