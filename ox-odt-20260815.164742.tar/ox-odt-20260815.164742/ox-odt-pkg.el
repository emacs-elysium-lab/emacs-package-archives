(define-package "ox-odt" "20260815.164742"
  "OpenDocument Text Exporter for Org Mode" '((org "9.2.1")) :authors
  '(("Jambunathan K" . "kjambunathanatgmaildotcom")) :maintainer
  '("Jambunathan K" . "kjambunathanatgmaildotcom") :keywords
  '("outlines" "hypermedia" "calendar" "wp") :url
  "https://github.com/kjambunathan/org-mode-ox-odt")
;; Local Variables:
;; no-byte-compile: t
;; End:
