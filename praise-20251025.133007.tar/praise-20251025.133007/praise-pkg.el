;;; Generated package description from praise.el  -*- no-byte-compile: t -*-
(define-package "praise" "20251025.133007" "Show git blame info in eldoc asynchronously" '((emacs "26.1") (async "1.8") (eldoc "1.16")) :authors '(("Ditto" . "ditto@mf.me")) :maintainer '("Ditto" . "ditto@mf.me") :keywords '("maint") :url "https://github.com/emacs-elysium-lab/praise-mode")
