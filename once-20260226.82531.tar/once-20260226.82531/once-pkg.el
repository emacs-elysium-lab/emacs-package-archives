(define-package "once" "20260226.82531"
  "Extra init.el deferred evaluation utilities." '((emacs "26.1"))
  :keywords '("convenience" "dotemacs" "startup" "config") :homepage
  "https://github.com/emacs-magus/once")
;; Local Variables:
;; no-byte-compile: t
;; End:
