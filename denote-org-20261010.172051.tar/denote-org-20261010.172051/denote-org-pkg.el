(define-package "denote-org" "20261010.172051"
  "Denote extensions for Org mode" '((emacs "28.1") (denote "4.0.0"))
  :authors '(("Protesilaos" . "info@protesilaos.com")) :maintainer
  '("Protesilaos" . "info@protesilaos.com") :url
  "https://github.com/protesilaos/denote-org")
;; Local Variables:
;; no-byte-compile: t
;; End:
