(define-package "chatgpt-shell" "20260919.42343"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)"
  '((emacs "28.1") (shell-maker "0.82.3") (transient "0.9.3")) :url
  "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
