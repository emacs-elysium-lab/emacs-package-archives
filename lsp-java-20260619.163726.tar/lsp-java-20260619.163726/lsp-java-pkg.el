(define-package "lsp-java" "20260619.163726"
  "Java support for lsp-mode"
  '((emacs "29.1") (lsp-mode "10.0.0") (markdown-mode "2.3")
    (dash "2.18.0") (f "0.20.0") (ht "2.0") (request "0.3.0")
    (treemacs "2.5") (dap-mode "0.5"))
  :keywords '("languague" "tools") :url
  "https://github.com/emacs-lsp/lsp-java")
;; Local Variables:
;; no-byte-compile: t
;; End:
