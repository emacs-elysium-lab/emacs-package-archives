;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-mode" "20261009.18"
  "Major mode for Markdown-formatted text."
  '((emacs "28.1"))
  :url "https://jblevins.org/projects/markdown-mode/"
  :commit "1d22840d588be29aa57eca36f28a32bede331550"
  :revdesc "1d22840d588b"
  :keywords '("markdown" "github flavored markdown" "itex")
  :authors '(("Jason R. Blevins" . "jblevins@xbeta.org"))
  :maintainers '(("Jason R. Blevins" . "jblevins@xbeta.org")))
