(define-package "consult-notes" "20250814.23455"
  "Manage notes with consult"
  '((emacs "27.1") (consult "0.17") (s "1.12.0") (dash "2.19"))
  :authors '(("Colin McLear" . "mclear@fastmail.com")) :keywords
  '("convenience") :url
  "https://github.com/mclear-tools/consult-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
